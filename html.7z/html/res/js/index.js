/// Document onload
$(document).ready(function() {
  const width = document.body.scrollWidth;

  ///  Main Slider
  $(".active-gallery-items").slick({
    arrows: false,
    dots: true,
    centerMode: true,
    centerPadding: "0px",
    slidesToShow: 1,
    mobileFirst: true,
    responsive: [
      {
        breakpoint: 767,
        settings: {
          centerMode: true,
          centerPadding: "0px",
          prevArrow: $(".arrow-left"),
          nextArrow: $(".arrow-right"),
          slidesToShow: 3,
          arrows: true
        }
      }
    ]
  });

  /// gallery
  $(".active-slider-items").slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    arrows: false,
    dots: false
  });

  ///  Sticky header
  (() => {
    let headerStickHeight = 700;

    if (width <= 767) {
      return;
    } else if (width <= 1024) {
      headerStickHeight = 500;
    }

    const headerWrapper = document.getElementById("header-wrapper");
    const headerLogo = document.getElementById("header-logo");
    window.addEventListener("scroll", e => {
      if (window.pageYOffset >= headerStickHeight) {
        headerWrapper.style.position = "fixed";
        headerLogo.style.display = "inline";
      } else {
        headerWrapper.style.position = "static";
        headerLogo.style.display = "none";
      }
    });
  })();
});
