$(document).ready(function() {
  $(".active-gallery-items").slick({
    arrows: false,
    dots: true,
    centerMode: true,
    centerPadding: "0px",
    slidesToShow: 1,
    mobileFirst: true,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: "0px",
          slidesToShow: 3
        }
      },
      {
        breakpoint: 1024,
        settings: {
          centerMode: true,
          centerPadding: "0px",
          prevArrow: $(".arrow-left"),
          nextArrow: $(".arrow-right"),
          slidesToShow: 3,
          arrows: true
        }
      }
    ]
  });

  $(".active-slider-items").slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    arrows: false,
    dots: true
  });
});
